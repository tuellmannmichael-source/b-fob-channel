# BLE Keyfob Proximity & Direction System

Detect proximity and direction of a BLE keyfob around a delivery vehicle using
a single Nordic nRF54L15 receiver with an RF switch (Skyworks SKYA21039)
cycling between three roof-mounted external antennas.

## System Overview

```
                 Top-down view of vehicle roof
    ┌──────────────────────────────────────────┐
    │              Ant A (front)                │
    │                  *                        │
    │                 / \                       │
    │  ┌────────┐   /   \                      │
    │  │nRF54L15│  / dir? \    BLE connection   │
    │  │ + RF   │ / dist?  \   to keyfob.       │
    │  │ switch │/          \  Hybrid ranging:  │
    │  └────────┘            \ CS + RSSI fallbk │
    │           *─────────────*                 │
    │       Ant B (left)   Ant C (right)        │
    │          rear           rear              │
    └──────────────────────────────────────────┘
```

## Hardware

| Component | Part | Role |
|-----------|------|------|
| Receiver MCU | nRF54L15 | BLE central, hybrid ranging (CS + RSSI), position engine |
| RF switch | Skyworks SKYA21039 (SP3T) | Route single radio to 3 antennas |
| Antennas (x3) | External BLE 2.4 GHz + UFL-SMA pigtail + 2m SMA cable | Roof-mounted, spread |
| CAN controller | MCP2518FD | Vehicle bus integration |
| External flash | Winbond W25Q128JVSI (128 Mbit) | Logging, OTA image storage |
| Keyfob MCU | nRF54L15 | BLE peripheral, heartbeat advertiser |

## Repository Structure

```
.
├── docs/
│   ├── architecture.md              # Single-device RF-switch architecture
│   ├── triangulation-math.md        # RSSI path-loss, Kalman filter, direction math
│   ├── ble-connection-management.md # Connection keep-alive & auto-reconnect
│   └── validation-rollout-plan.md   # Test stages, acceptance KPIs, logging, rollout
├── firmware/                        # Receiver firmware (nRF Connect SDK / Zephyr)
│   ├── CMakeLists.txt
│   ├── prj.conf
│   ├── Kconfig
│   └── src/
│       ├── main.c
│       ├── ble/                     # BLE connection management
│       ├── triangulation/           # RSSI filter + trilateration engine
│       └── config/                  # Antenna geometry & app config
├── keyfob/                          # Keyfob firmware (nRF54L15)
│   ├── CMakeLists.txt
│   ├── prj.conf
│   └── src/
├── simulation/                      # Python simulation & visualization
│   ├── requirements.txt
│   ├── triangulation_sim.py
│   └── rssi_model.py
└── tests/                           # Unit tests
```

## Quick Start

### Prerequisites

- nRF Connect SDK v2.9+ (nRF54L15 support)
- Nordic command-line tools (`nrfjprog`, `nrfutil`)
- Python 3.10+ (for simulation)

### Build receiver firmware

```bash
cd firmware
west build -b nrf54l15dk/nrf54l15/cpuapp
west flash
```

### Build keyfob firmware

```bash
cd keyfob
west build -b nrf54l15dk/nrf54l15/cpuapp
west flash
```

### Run simulation

```bash
cd simulation
pip install -r requirements.txt
python triangulation_sim.py
```

## Key Design Decisions

1. **Single device baseline** -- The current firmware path is single-device and
   BLE-connection-based. It is structured to integrate RF-switch antenna
   rotation, while keeping RSSI filtering + trilateration isolated in the
   triangulation module.
2. **Proximity + direction (not full 2D tracking)** -- Compare RSSI ratios
   between antennas for direction sector, average RSSI for distance band.
   Simpler and more robust than full trilateration.
3. **Connection-based with scan fallback** -- Maintain a BLE connection for
   reliable RSSI at a controlled interval. Auto-reconnect with exponential
   backoff if the link drops.
4. **Hybrid ranging pipeline** -- Triangulation accepts explicit
   distance+uncertainty measurements. BLE manager now starts/stops a dedicated
   Channel Sounding session lifecycle when enabled, with RSSI-based fallback.
5. **Kalman filter per antenna** -- Smooth raw RSSI before fallback
   distance computation.
6. **CTE/AoA upgrade path** -- The RF switch GPIO timing can later be wired
   into the nRF54L15 Direction Finding antenna-switching pattern for
   phase-based AoA (higher precision).

## Combined PR Scope

This branch combines previously separated deliverables into one integrated
baseline that can be approved together:

- Migration to a single nRF54L15 receiver architecture with an RF-switched
  3-antenna array.
- Addition of a Channel Sounding session lifecycle adapter and associated BLE
  manager integration for start/stop handling.
- Baseline nRF54L15 Channel Sounding configuration and peer-to-peer ranging
  profile defaults.

If you need to review in one pass, use this branch as the consolidated source
of truth for architecture, BLE connection/channel-sounding flow, and ranging
configuration.

## License

MIT
